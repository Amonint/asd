public class App {
    public static void main(String[] args) throws Exception {
        int x[][]={{3,3,3},{3,3,4}};
       

        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x[0].length; j++) {
                System.out.println(x[i][j]);
                
            }
        }
       
    }
    
}

