/* public class problema2 {
    public static void main(String[] args) throws Exception {
        int[] filas = {3,2,3};
        int[] columnas = {3,2,3,5};
        int AP=0,Ai=0;

        for (int i = 0; x < filas.length; i++) {
            for (int j = 0; x < columnas[0].length; j++) {
                if(x[i][j]%2=0);
                    Ap+=x[i][j];
                else
                    Ai=x[i][j];
            }
        }
        
        System.out.println("");
    }
} */